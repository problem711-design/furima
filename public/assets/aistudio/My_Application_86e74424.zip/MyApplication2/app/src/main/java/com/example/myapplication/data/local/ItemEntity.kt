package com.example.myapplication.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "items")
data class ItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val status: String = "LISTED", // "LISTED" (出品中), "SOLD" (売却済み), "DRAFT" (未出品)
    val price: Int = 0, // 出品価格
    val soldPrice: Int = 0, // 実際の売却価格
    val shippingCost: Int = 0, // 送料
    val feeRatePercent: Int = 10, // 販売手数料 % (デフォルト10% = メルカリ等)
    val createdAt: Long = System.currentTimeMillis()
) {
    val calculatedProfit: Int
        get() {
            val basePrice = if (status == "SOLD" && soldPrice > 0) soldPrice else price
            val fee = (basePrice * feeRatePercent) / 100
            return (basePrice - fee - shippingCost).coerceAtLeast(0)
        }
}
