package com.example.myapplication.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.FleaMarketRepository
import com.example.myapplication.data.local.ItemEntity
import com.example.myapplication.data.local.ItemWithPhotos
import com.example.myapplication.data.local.SalesSummary
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FleaMarketViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = FleaMarketRepository(application)

    val itemsWithPhotos: StateFlow<List<ItemWithPhotos>> = repository.getAllItemsWithPhotos()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val salesSummary: StateFlow<SalesSummary> = repository.getSalesSummary()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SalesSummary()
        )

    suspend fun getItemById(id: Int): ItemWithPhotos? {
        return repository.getItemById(id)
    }

    fun saveItem(
        id: Int,
        title: String,
        status: String,
        price: Int,
        soldPrice: Int,
        shippingCost: Int,
        feeRatePercent: Int,
        imageUris: List<Uri>,
        existingFilePaths: List<String>,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.saveItem(
                id = id,
                title = title,
                status = status,
                price = price,
                soldPrice = soldPrice,
                shippingCost = shippingCost,
                feeRatePercent = feeRatePercent,
                imageUris = imageUris,
                existingFilePaths = existingFilePaths
            )
            onSuccess()
        }
    }

    fun updateItemStatus(item: ItemEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateItemStatus(item, newStatus)
        }
    }

    fun deleteItem(itemWithPhotos: ItemWithPhotos, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.deleteItem(itemWithPhotos)
            onSuccess()
        }
    }

    fun shareItemPhotos(context: Context, photoPaths: List<String>) {
        val shareIntent = repository.getPhotoStorageManager().createShareIntent(photoPaths)
        val chooserIntent = Intent.createChooser(shareIntent, "LocalSend等でPCに共有")
        chooserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooserIntent)
    }
}
