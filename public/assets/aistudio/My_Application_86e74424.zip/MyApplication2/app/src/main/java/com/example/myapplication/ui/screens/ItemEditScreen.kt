package com.example.myapplication.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.myapplication.data.PhotoStorageManager
import com.example.myapplication.ui.FleaMarketViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemEditScreen(
    itemId: Int,
    viewModel: FleaMarketViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var soldPriceText by remember { mutableStateOf("") }
    var shippingCostText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("LISTED") }

    val newImageUris = remember { mutableStateListOf<Uri>() }
    val existingFilePaths = remember { mutableStateListOf<String>() }

    var cameraPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var tempCameraPath by remember { mutableStateOf<String?>(null) }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        newImageUris.addAll(uris)
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempCameraPath != null) {
            existingFilePaths.add(tempCameraPath!!)
        }
    }

    LaunchedEffect(itemId) {
        if (itemId != 0) {
            val itemWithPhotos = viewModel.getItemById(itemId)
            if (itemWithPhotos != null) {
                val item = itemWithPhotos.item
                title = item.title
                priceText = if (item.price > 0) item.price.toString() else ""
                soldPriceText = if (item.soldPrice > 0) item.soldPrice.toString() else ""
                shippingCostText = if (item.shippingCost > 0) item.shippingCost.toString() else ""
                status = item.status
                existingFilePaths.addAll(itemWithPhotos.photos.map { it.filePath })
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (itemId == 0) "新規出品・写真フォルダ作成" else "出品情報・写真編集") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "戻る")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "📸 出品写真の追加 (複数可)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        pickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                ) {
                    Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ギャラリーから選択")
                }

                OutlinedButton(
                    onClick = {
                        val manager = PhotoStorageManager(context)
                        val pair = manager.createTempCameraPhotoUri(title.ifBlank { "Unassigned" })
                        if (pair != null) {
                            cameraPhotoUri = pair.first
                            tempCameraPath = pair.second
                            cameraLauncher.launch(pair.first)
                        }
                    }
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("撮影")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (existingFilePaths.isNotEmpty() || newImageUris.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(existingFilePaths) { path ->
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = File(path),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .clickable { existingFilePaths.remove(path) }
                                    .align(Alignment.TopEnd)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "削除",
                                    tint = Color.White,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }

                    items(newImageUris) { uri ->
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = uri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .clickable { newImageUris.remove(uri) }
                                    .align(Alignment.TopEnd)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "削除",
                                    tint = Color.White,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            } else {
                Text(
                    text = "写真がまだ選択されていません",
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "📝 出品フォルダ属性・情報入力",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("フォルダ名・商品タイトル") },
                placeholder = { Text("例: Nike スニーカー 27cm") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it },
                label = { Text("出品価格 (円)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = shippingCostText,
                onValueChange = { shippingCostText = it },
                label = { Text("想定送料 (円)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (status == "SOLD") {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = soldPriceText,
                    onValueChange = { soldPriceText = it },
                    label = { Text("実際の売却価格 (円)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("販売ステータス:", fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = (status == "LISTED"),
                    onClick = { status = "LISTED" }
                )
                Text("出品中", modifier = Modifier.clickable { status = "LISTED" })

                Spacer(modifier = Modifier.width(16.dp))

                RadioButton(
                    selected = (status == "SOLD"),
                    onClick = { status = "SOLD" }
                )
                Text("売却済み", modifier = Modifier.clickable { status = "SOLD" })

                Spacer(modifier = Modifier.width(16.dp))

                RadioButton(
                    selected = (status == "DRAFT"),
                    onClick = { status = "DRAFT" }
                )
                Text("未出品", modifier = Modifier.clickable { status = "DRAFT" })
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val price = priceText.toIntOrNull() ?: 0
                    val soldPrice = soldPriceText.toIntOrNull() ?: price
                    val shippingCost = shippingCostText.toIntOrNull() ?: 0

                    if (title.isNotBlank()) {
                        viewModel.saveItem(
                            id = itemId,
                            title = title,
                            status = status,
                            price = price,
                            soldPrice = soldPrice,
                            shippingCost = shippingCost,
                            feeRatePercent = 10,
                            imageUris = newImageUris,
                            existingFilePaths = existingFilePaths,
                            onSuccess = onNavigateBack
                        )
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("保存する", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
