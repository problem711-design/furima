package com.example.myapplication.data

import android.content.Context
import android.net.Uri
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.local.ItemEntity
import com.example.myapplication.data.local.ItemWithPhotos
import com.example.myapplication.data.local.PhotoEntity
import com.example.myapplication.data.local.SalesSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FleaMarketRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val dao = db.itemDao()
    private val photoStorageManager = PhotoStorageManager(context)

    fun getAllItemsWithPhotos(): Flow<List<ItemWithPhotos>> = dao.getAllItemsWithPhotos()

    fun getSalesSummary(): Flow<SalesSummary> {
        return dao.getAllItems().map { items ->
            var totalSales = 0
            var totalProfit = 0
            var listedCount = 0
            var soldCount = 0

            for (item in items) {
                if (item.status == "SOLD") {
                    soldCount++
                    val price = if (item.soldPrice > 0) item.soldPrice else item.price
                    totalSales += price
                    totalProfit += item.calculatedProfit
                } else if (item.status == "LISTED") {
                    listedCount++
                }
            }
            SalesSummary(totalSales, totalProfit, listedCount, soldCount)
        }
    }

    suspend fun getItemById(id: Int): ItemWithPhotos? {
        return dao.getItemWithPhotosById(id)
    }

    suspend fun saveItem(
        id: Int = 0,
        title: String,
        status: String,
        price: Int,
        soldPrice: Int,
        shippingCost: Int,
        feeRatePercent: Int,
        imageUris: List<Uri>,
        existingFilePaths: List<String> = emptyList()
    ): Long {
        val item = ItemEntity(
            id = id,
            title = title,
            status = status,
            price = price,
            soldPrice = soldPrice,
            shippingCost = shippingCost,
            feeRatePercent = feeRatePercent
        )

        val itemId = if (id == 0) {
            dao.insertItem(item).toInt()
        } else {
            dao.updateItem(item)
            id
        }

        val savedPhotoPaths = mutableListOf<String>()
        savedPhotoPaths.addAll(existingFilePaths)

        for (uri in imageUris) {
            val savedPath = photoStorageManager.savePhotoFromUri(title, uri)
            if (savedPath != null) {
                savedPhotoPaths.add(savedPath)
            }
        }

        dao.deletePhotosByItemId(itemId)
        val photoEntities = savedPhotoPaths.mapIndexed { index, path ->
            PhotoEntity(itemId = itemId, filePath = path, displayOrder = index)
        }
        dao.insertPhotos(photoEntities)

        return itemId.toLong()
    }

    suspend fun updateItemStatus(item: ItemEntity, newStatus: String) {
        val updated = item.copy(status = newStatus)
        dao.updateItem(updated)
    }

    suspend fun deleteItem(itemWithPhotos: ItemWithPhotos) {
        dao.deleteItem(itemWithPhotos.item)
    }

    fun getPhotoStorageManager(): PhotoStorageManager = photoStorageManager
}
