package com.example.myapplication.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PhotoStorageManager(private val context: Context) {

    fun getItemImageDir(itemTitle: String): File {
        val safeTitle = itemTitle.replace(Regex("[^a-zA-Z0-9_\\-\\u3040-\\u309F\\u30A0-\\u30FF\\u4E00-\\u9FFF]"), "_")
            .ifBlank { "Item" }
        val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        val appDir = File(picturesDir, "FleaMarket/$safeTitle")
        if (!appDir.exists()) {
            appDir.mkdirs()
        }
        return appDir
    }

    fun savePhotoFromUri(itemTitle: String, sourceUri: Uri): String? {
        return try {
            val dir = getItemImageDir(itemTitle)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.getDefault()).format(Date())
            val file = File(dir, "IMG_$timeStamp.jpg")

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(file).use { output ->
                    input.copyTo(output)
                }
            }
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun createTempCameraPhotoUri(itemTitle: String): Pair<Uri, String>? {
        return try {
            val dir = getItemImageDir(itemTitle)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.getDefault()).format(Date())
            val file = File(dir, "CAMERA_$timeStamp.jpg")
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, file)
            Pair(uri, file.absolutePath)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun createShareIntent(photoFilePaths: List<String>): Intent {
        val uris = ArrayList<Uri>()
        val authority = "${context.packageName}.fileprovider"

        for (path in photoFilePaths) {
            val file = File(path)
            if (file.exists()) {
                val uri = FileProvider.getUriForFile(context, authority, file)
                uris.add(uri)
            }
        }

        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
